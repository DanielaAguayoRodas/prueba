import { BrowserRouter,Routes,Route } from "react-router-dom";
import Inicio from './components/inicio'
import Personaje from './components/personaje'
import * as React from 'react';
import Box from '@mui/material/Box';
import { DataGrid } from '@mui/x-data-grid';
import { todosPersonajes } from "./funciones/funciones";


export default function App() {
  return (
    
    <div className="contenedor">
      <BrowserRouter>
      <Routes>
        <Route path='/' element= {<Inicio></Inicio>}></Route>
        <Route path='/personaje/:id' element={<Personaje></Personaje>}></Route>
      </Routes>

    </BrowserRouter>
    </div>
  );
}
const columns = [
  { field: 'id', headerName: 'ID', width: 90 },
  {
    field: 'firstName',
    headerName: 'First name',
    width: 150,
    editable: true,
    valueGetter: (params) => 
    `{params.id},`
  },
  {
    field: 'lastName',
    headerName: 'Last name',
    width: 150,
    editable: true,
    valueGetter: (params) => 
    `{params.last_name},`

  },
  
];

export function DataGridDemo() {
  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={todosPersonajes}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5]}
        checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
}
