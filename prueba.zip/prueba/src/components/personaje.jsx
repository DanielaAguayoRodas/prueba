import React, {useEffect, useState} from 'react'
import { useParams } from 'react-router-dom'
import { unicoPersonaje } from '../funciones/funciones'


const Personaje = () => {

    const[personaje, setPersonaje] = useState(null)
    const params =useParams()

   useEffect(() => {
    unicoPersonaje(params.id, setPersonaje)
}, [])
    
    return(
        <>
        <h2>Personaje con el id {params.id} </h2>
        <h2>Personaje con el nombre{personaje.last_name}
        {personaje.last_name}</h2>
        <p>email{personaje.email}</p>
       
        <p></p>
        
        </>
    )
}

export default Personaje