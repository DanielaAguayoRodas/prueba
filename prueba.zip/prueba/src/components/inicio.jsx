import React, {useEffect, useState} from 'react'
import { todosPersonajes } from '../funciones/funciones'



const Inicio = () => {

    const[personajes, setPersonajes] = useState(null)

useEffect(() => {
     if (!personajes){
        todosPersonajes(setPersonajes)
     }
}, [])


    return(
        <>
        {personajes != null ?(
        personajes.map(personaje => (
                <div key={personaje.id}>
                    <a href={`/personaje/${personaje.id}`}> {personaje.first_name}</a>
                </div>
        ))
         ): ("no hay personajes")}
        </>
    )
}

export default Inicio