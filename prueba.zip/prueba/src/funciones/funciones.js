import axios from "axios"

const todosPersonajes = async (state) => {
    const peticion = await axios.get('https://random-data-api.com/api/users/random_user?size=20')
    state(peticion.data)
    console.log(peticion.data)
    
}

const unicoPersonaje = async (id, state) => {
    const peticion = await axios.get('https://random-data-api.com/api/users/random_user?size=20'+id)
    state(peticion.data)
    
}

export {
    todosPersonajes,
    unicoPersonaje
}